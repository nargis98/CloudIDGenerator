-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2024 at 11:39 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id_card`
--

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE `cards` (
  `sno` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `grade` varchar(10) DEFAULT NULL,
  `id_no` varchar(15) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `phone` varchar(12) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `dob` varchar(20) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `exp_date` varchar(20) DEFAULT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cards`
--

INSERT INTO `cards` (`sno`, `name`, `grade`, `id_no`, `email`, `phone`, `address`, `dob`, `date`, `exp_date`, `image`) VALUES
(725, 'Nargis', NULL, '3545353', 'Nargis@gmail.com]', '0725689187', 'Luton, United Kingdom', '1994-06-01', '2024-05-01 22:10:49', '2024-09-13', 'assets/uploads/images.jpg'),
(726, 'Hoor', NULL, '4563563', 'Hoor@gmail.com]', '', 'Luton, United Kingdom', '2021-02-07', '2024-05-03 13:36:36', '2024-02-19', 'assets/uploads/USER.png'),
(724, 'Faiza', NULL, '4927492', 'faiza@gmail.com]', '928701378013', '372 Icknield Way LU32JU, Luton', '1992-08-13', '2024-04-22 21:27:57', '2024-09-19', 'assets/uploads/dp4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password_hash`) VALUES
(1, 'narigis', 'nargis@gmail.com', '$2y$10$9aUO0B7vJrFn/wNI0Tz7jOPX6rIciLJ1Bq67/xSLcsu61vOYi./yu'),
(2, 'nargiss', 'nargiss@gmail.com', '$2y$10$Fk.Jo2I3/8fODYtkRnaSQuAHFB2u.9XK0UX6DXGzFNiFLgtGdI5xi'),
(3, 'hoor', 'hoor@gmail.com', '$2y$10$VsGNvWtRNBTCmswwNUCWG.t1ZA7bK/C3LQYRRjIHjLM6v7YR1Mc2G'),
(4, 'hoorain', 'hoorain@gmail.com', '$2y$10$hi2eJksd/sZJf7WIGQ1pw.KB9j2KCIBTbCa7K.Kz2AxDn27fsUyYO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cards`
--
ALTER TABLE `cards`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=727;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
